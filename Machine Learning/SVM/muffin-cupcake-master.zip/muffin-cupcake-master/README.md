# muffin-cupcake
classifying muffin and cupcake recipes using support vector machines

the supporting youtube tutorial can be found here: https://youtu.be/N1vOgolbjSc

what's the difference between a muffin and a cupcake? turns out muffins have more flour, while cupcakes have more butter and sugar.
